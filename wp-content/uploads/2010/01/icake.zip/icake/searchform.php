<form action="<?php bloginfo('home'); ?>/" id="searchform" method="get">
<label for="zoeken" class="hidden">Search for:</label>
<div><input type="text" id="zoeken" name="s" value=""/>
<input type="image" value="zoek" id="searchsubmit" src="<?php bloginfo('template_url'); ?>/images/searchbutton.gif"/>
</div>
</form>
