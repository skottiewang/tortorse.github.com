<?php // Do not delete these lines

	if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');

	if (!empty($post->post_password)) { // if there's a password
            if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
				?>

				<p class="nocomments"><?php echo $langpost_password_commenrs; ?><p>

				<?php
				return;
            }
        }

		/* This variable is for alternating comment background */
		$oddcomment = 'alt';

?>

	<?php if ($comments) : ?>
	<ol class="commentlist">
		<?php foreach ($comments as $comment) : ?>
		<li class="<?php echo
		$oddcomment;
		$comment_type = get_comment_type();
		if ($comment->comment_author_email == get_the_author_email()) :
		echo ' authorcomment';
		elseif($comment_type == 'trackback' || $comment_type == 'pingback') :
		echo ' trackback';
		endif;
		?>" id="comment-<?php comment_ID() ?>">
        <div id="div-comment-<?php comment_ID() ?>">
        <div class="vcard">
        <?php
			$comment_type = get_comment_type();
			// common setting
			if($comment_type == 'comment') :
			echo get_avatar( get_comment_author_email(), '50' );
			// Trackback & pingback setting
			elseif($comment_type == 'trackback' || $comment_type == 'pingback') :
			echo "<img src='/wp-content/uploads/trackback.png' alt='Trackback/Pingback' class='avatar' />";
			endif;
			?>
            <cite class="fn">
			<?php comment_author_link(); ?>
            </cite>
           </div>
           <?php comment_text() ?>
			<div class="commentmetadata"><a href="<?php the_permalink() ?>#comment-<?php comment_ID() ?>"><?php comment_date('F jS, Y') ?> at <?php comment_time() ?></a></div>
		</div>
		</li>
		
		<?php /* Changes every other comment to a different class */
			if ('alt' == $oddcomment) $oddcomment = '';
			else $oddcomment = 'alt';
		?>
		<?php endforeach; /* end for each comment */ ?>
	</ol>

	<?php else : // this is displayed if there are no comments so far ?>

		<?php if ('open' == $post->comment_status) : ?> 
			<!-- If comments are open, but there are no comments. -->

		 <?php else : // comments are closed ?>
			<!-- If comments are closed. -->
			<p class="nocomments"><?php echo "Comments are closed.";?></p>

		<?php endif; ?>
	<?php endif; ?>

	<?php if ('open' == $post->comment_status) : ?>
	<h3 id="respond">Leave a Reply</h3>
	<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
	<p><a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php the_permalink(); ?>"><?php echo "您必须登陆才可以发表评论"?></a></p>
	<?php else : ?>
	<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
		<?php if ( $user_ID ) : ?>
		<p><?php echo "Logged in as"?> <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="Log out of this account"><?php echo "Log out"?> &raquo;</a></p>
		<?php else : ?>
		<p><input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="22" tabindex="1" />
        <label for="author">Name *</label></p>
		<p><input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="22" tabindex="2" />
        <label for="email">Mail *</label></p>
		<p><input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="22" tabindex="3" />
        <label for="url">Website</label></p>
		<?php endif; ?>
		<p><textarea name="comment" id="comment" rows="10" tabindex="4"></textarea></p>
		<p><input name="submit" type="submit" id="submit" tabindex="5" value="Submit Comment" />
		<input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" /></p>
        <p>* Name, email, and comment required. Email will never be displayed. You can use a <a target="_blank" href="http://en.gravatar.com/">Gravatar</a>.</p>
		<?php do_action('comment_form', $post->ID); ?>
        
	</form>
	<?php endif; // If registration required and not logged in ?>
	<?php endif; // if you delete this the sky will fall on your head ?>