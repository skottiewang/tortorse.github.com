$(document).ready(function(){
	$('#nav_list li').mouseover(
		function(){
		$(this).addClass("on");
		}	
	)
	$('#nav_list li').mouseout(
		function(){
		$(this).removeClass("on");
		}	
	)
	})