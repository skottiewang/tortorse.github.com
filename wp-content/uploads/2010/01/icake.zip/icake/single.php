<?php get_header(); ?>
<div id="content" class="narrowcolumn">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<div class="post" id="post-<?php the_ID(); ?>">
				<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                <div class="entry_info">
					<span class="date"><?php the_time('F') ?> <?php the_time('j') ?>, <?php the_time('Y') ?></span> | Posted in 
					<span class="tag">
					<?php the_category(','); ?>
					 </span>
					 |
					 <span class="comments"><a title="<?php the_title(); ?>" href="<?php the_permalink() ?>#respond"><?php comments_number('No Comments','1 Comments','% Comments'); ?></a></span><?php edit_post_link('edit',' | ',''); ?>
				</div>
			  <div class="entry">
					<?php the_content(); ?>
                    <p class="postmetadata"><?php the_tags(); ?></p>
                  <p class="postmetadata2">
                   	  <small>This entry was posted on
					  <?php the_time('F') ?> <?php the_time('j') ?>, <?php the_time('Y') ?> at <?php the_time('g:i a'); ?>
                      feel free to
                      <a href="#respond"><strong>leave a comment</strong></a>
                      or
                      <a href="<?php trackback_url(); ?>"><strong>link to it</strong></a>.
                      </small>
                      </p>
			  </div>             
			</div>
            <h3><?php comments_number('0', '1', '%'); ?> persons have commented (^_^)</h3>
            <p>feel free to <a href="#respond">add your reply</a></p>
			<?php comments_template(); ?>
		<?php endwhile; else: ?>
			<br /><h2 class="center">oops!here is no more contents.</h2>
		<?php endif; ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>