<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php if ( is_home() ) { ?><? bloginfo('name'); ?> - <?php bloginfo('description'); ?><?php } ?><?php if ( is_search() ) { ?><?php echo $s; ?> - <? bloginfo('name'); ?><?php } ?><?php if ( is_single() ) { ?><?php wp_title(''); ?><?php } ?><?php if ( is_page() ) { ?><?php wp_title(''); ?><?php } ?><?php if ( is_category() ) { ?><?php single_cat_title(); ?><?php } ?><?php if ( is_month() ) { ?><?php the_time('F'); ?><?php } ?><?php if ( is_tag() ) { ?><?php single_tag_title();?><?php } ?>
</title>
<?php if (is_home()){
$description = "";/*input your blog introduce text*/
$keywords = "";/*input your blog keyword*/
} elseif (is_single()){
if ($post->post_excerpt) {
        $description     = $post->post_excerpt;
    } else {
        $description = substr(strip_tags($post->post_content),0,220);
    }
 
    $keywords = "";       
    $tags = wp_get_post_tags($post->ID);
    foreach ($tags as $tag ) {
        $keywords = $keywords . $tag->name . ", ";
    }
}
?>
<meta name="keywords" content="<?php echo $keywords ?>" />
<meta name="description" content="<?php echo $description ?>" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" type="text/css" />
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/nav.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.pngFix.js"></script>
<script type="text/javascript"> 
    $(document).ready(function(){ 
		$('#cup').pngFix(); 
    }); 
</script> 
</head>

<body>
<div id="wrapper">
	<div id="header">
		<div id="header_img">
			<img id="cup" src="<?php bloginfo('template_url'); ?>/images/header_cup.png" alt="<?php bloginfo('name'); ?>" width="235" height="157" />
			<a id="home" href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>
			<div id="nav">
				<ul id="nav_list" class="clearfix">
				<li><a href="<?php echo get_settings('home'); ?>/">index</a></li>
					<?php
                           // wp_list_categories('title_li=0&orderby=name&show_count=0');
                            wp_list_pages('title_li=0&sort_column=menu_order&depth=2&number=10');
                    ?>
				</ul>
			</div>
		</div>
	</div>
	<div id="main" class="clearfix">
	<div id="content_top">
			<?php
				$count_posts = wp_count_posts();
				$published_posts = $count_posts->publish;
			?>
			<span><a href="<?php echo get_settings('home'); ?>">Total: <?php echo $published_posts  ?> Post</a></span>
	</div>
