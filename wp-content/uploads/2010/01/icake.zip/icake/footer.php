	</div>
<div id="footer">
    <div id="footerarea">
        <span id="footerleft">
            © 2009 - 2010 <?php bloginfo('name'); ?> All rights reserved. | <b>Subscribe: <a href="<?php bloginfo('rss2_url'); ?>">Entries</a> | <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments</a></b> | <a href="http://technorati.com/faves?sub=addfavbtn&amp;add=<?php bloginfo('url'); ?>"><img alt="Add to Technorati Favorites" src="<?php bloginfo('template_url'); ?>/images/btn-fave2.png"/></a>
		</span>
        <span id="footerright">  
        Powered by <a href="http://wordpress.org/">WordPress</a> | Theme by <a href="http://taozhe.net/log/" target="_blank">tortorse</a>
		</span>
		</div>
</div>
</div>
</body>
</html>
