<?php get_header(); ?>
<div id="content" class="narrowcolumn">
	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
		<div class="post" id="post-<?php the_ID(); ?>">
			<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
			<div class="entry_info">
					<span class="date"><?php the_time('F') ?> <?php the_time('j') ?>, <?php the_time('Y') ?></span> | Posted in 
					<span class="tag">
					<?php /*the_tags('',',','');*/
					the_category(',');
					 ?>
					 </span>
					 |
					 <span class="comments"><a title="<?php the_title(); ?>" href="<?php the_permalink() ?>#respond"><?php comments_number('No Comments','1 Comments','% Comments'); ?></a></span><?php edit_post_link('edit',' | ',''); ?>
				</div>
			<div class="entry">
				<?php the_content('<br />read more &raquo;'); ?>
			</div>
			<div class="entry_footer"><a title="<?php the_title(); ?>#respond" href="<?php the_permalink() ?>"><?php comments_number('No Comments','1 Comments','% Comments'); ?></a> about <?php the_title(); ?></div>
		</div>
		<?php endwhile; ?>
		<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } else{?>
		<div class="navigation">
			<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
			<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
		</div>
		<?php }?> 	
	<?php else : ?>
		<br /><h2 class="center">oops!here is no more contents.</h2>
	<?php endif; ?>
	</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
