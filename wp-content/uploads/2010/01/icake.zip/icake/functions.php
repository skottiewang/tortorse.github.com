<?php

// Removes the white spaces from wp_title
function af_titledespacer($title) {
	return trim($title);
}
add_filter('wp_title', 'af_titledespacer');

?>