<div id="sidebar">
	<ul>
		<li class="widget widget_search" id="search">
			<?php get_search_form(); ?>
		</li>
		<li class="widget widget_recent_entries" id="recent-posts">	
			<h2 class="widgettitle">Fresh Posts</h2>
			<ul>
			 <?php
			 $last_posts = get_posts('numberposts=3&orderby=rand');
			 foreach( $last_posts as $post ) :
 			?><li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li><?php endforeach; ?></ul>
		</li>
		<li class="widget widget_categories">
			<h2 class="widgettitle">Tags - pick your flavour</h2>
            <ul>
           <?php /*$tags = wp_tag_cloud("format=array&smallest=8&largest=8&number=10&orderby=count"); 
		   foreach ($tags as $tag){
		   echo "<li class=\"cat-item\">".$tag."</li>";
		   }*/
		   wp_list_categories('title_li=0&orderby=name&show_count=0&depth=1&number=10&style=list');
		   ?></ul>
		</li>
		<?php /* If this is the frontpage */ if ( is_home() || is_page() ) { ?>
		<li class="widget widget_links" id="linkcat-2">
				<h2 class="widgettitle">Blogroll</h2>
				<ul class="xoxo blogroll">
				<?php wp_list_bookmarks('title_li=&categorize=0');?>
				</ul>
		</li>
		<?php } ?>
	</ul>
</div>